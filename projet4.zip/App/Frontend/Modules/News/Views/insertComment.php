<h2>Ajouter un commentaire</h2>
<form action="" method="post">
    <?= $form ?>
    
    <input type="submit" value="Commenter" />
</form>