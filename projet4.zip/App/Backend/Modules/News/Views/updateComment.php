<h3>Modifier un commentaire</h3>
<form action="" method="post">
  <p>
    <?= $form ?>
 
    <input type="submit" value="Modifier" />
  </p>
</form>