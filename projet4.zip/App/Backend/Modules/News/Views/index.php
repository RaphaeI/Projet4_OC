<h3>Espace administration</h3>
<div id="adminPanel">
	<div>
		<a href="/admin/article">
			<i class="far fa-newspaper"></i>
			<h4>NEWS</h4>
		</a>
	</div>

	<div>
		<a href="/admin/commentary">
			<i class="fas fa-comments"></i>
			<H4>COMMENTAIRES</H4>
		</a>
	</div>
	
</div>

