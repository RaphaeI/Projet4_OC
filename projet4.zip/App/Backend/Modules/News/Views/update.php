<h3>Modifier une news</h3>
<form action="" method="post">
  <p>
    <?= $form ?>
 
    <input type="submit" value="Modifier" />
  </p>
</form>