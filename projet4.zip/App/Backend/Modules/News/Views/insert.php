<h3>Ajouter une news</h3>
<form action="" method="post">
    <?= $form ?> 
    <input type="submit" value="Ajouter" />
</form>