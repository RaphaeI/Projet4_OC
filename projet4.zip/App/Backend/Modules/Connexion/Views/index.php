<h3>connexion à l'espace d'administration</h3>
<form action="" method="post">
	<label>Login</label>
	<input type="text" name="login" />
	<label>Mot de passe</label>
	<input type="password" name="password" /> 
	<input type="submit" value="Connexion" />
</form>
